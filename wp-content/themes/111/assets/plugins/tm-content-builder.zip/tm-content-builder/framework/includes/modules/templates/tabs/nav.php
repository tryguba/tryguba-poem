<?php
/**
 * Template part for displaying tabs navigation block
 */
?>
<ul class="tm_pb_tabs_controls clearfix">
	<?php echo $this->_var( 'nav_items' ); ?>
</ul>